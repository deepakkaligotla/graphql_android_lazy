package `in`.kaligotla.list_and_grids.core

object Constants {
    //App
    const val TAG = "AppTag"

    //Screens
    const val FIRST_SCREEN = "First"
}