package `in`.kaligotla.list_and_grids

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class ListsGridsApp: Application()